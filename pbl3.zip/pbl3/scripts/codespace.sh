#!/usr/bin/env bash
# ONE command inside a GitHub Codespace:  sudo -E bash pbl3/scripts/codespace.sh
# Builds everything: private registry, Kubernetes (k3d), Git server, pre-configured Jenkins,
# runs all 3 PBL pipelines once and prints your links. Safe to run again.
set -uo pipefail
SRC="$(cd "$(dirname "$0")/.." && pwd)"
GIT_BARE=/srv/git/medicare-devops.git
WORK=/opt/medicare-work
PASS_FILE=/root/jenkins-admin-password.txt
CFG=/etc/pbl3
[ "$(id -u)" -eq 0 ] || exec sudo -E bash "$0" "$@"
export PATH=/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH HOME=/root
step() { echo; echo "================  $*  ================"; }
mkdir -p $CFG

# Link format for this codespace
if [ -n "${CODESPACE_NAME:-}" ]; then
  echo "https://${CODESPACE_NAME}-PORT.${GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN:-app.github.dev}" > $CFG/urlbase
else
  echo "http://localhost:PORT" > $CFG/urlbase
fi

# keep printing so the codespace never looks idle during the long steps
( while sleep 60; do echo "   ...still working ($(date +%H:%M))"; done ) & HEARTBEAT=$!
trap 'kill $HEARTBEAT 2>/dev/null' EXIT

step "1/6  Checking Docker"
docker info >/dev/null 2>&1 || { echo "Docker is not running in this codespace. Use the default codespace (Code > Codespaces > Create)."; exit 1; }
command -v kubectl >/dev/null || { curl -fsSLo /usr/local/bin/kubectl "https://dl.k8s.io/release/$(curl -fsSL https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"; chmod +x /usr/local/bin/kubectl; }
command -v k3d >/dev/null || curl -fsSL https://raw.githubusercontent.com/k3d-io/k3d/main/install.sh | bash

step "2/6  Private image registry + Kubernetes cluster"
docker start registry >/dev/null 2>&1 || docker run -d --restart always -p 5000:5000 --name registry registry:2
cat > $CFG/registries.yaml <<'YAML'
mirrors:
  "localhost:5000":
    endpoint:
      - "http://host.k3d.internal:5000"
YAML
if ! k3d cluster list 2>/dev/null | grep -q '^pbl '; then
  k3d cluster create pbl --api-port 127.0.0.1:6550 \
    -p "30007:30007@server:0" -p "30008:30008@server:0" -p "30018:30018@server:0" -p "30009:30009@server:0" \
    --registry-config $CFG/registries.yaml --k3s-arg "--disable=traefik@server:0" --wait
else
  k3d cluster start pbl >/dev/null 2>&1 || true
fi
k3d kubeconfig get pbl > $CFG/kubeconfig
export KUBECONFIG=$CFG/kubeconfig
until kubectl get nodes 2>/dev/null | grep -q " Ready"; do sleep 3; done
for u in codespace vscode; do id $u >/dev/null 2>&1 && { mkdir -p /home/$u/.kube; cp $CFG/kubeconfig /home/$u/.kube/config; chown -R $u /home/$u/.kube; }; done
kubectl get nodes

step "3/6  Git server for the project code"
if [ ! -d "$GIT_BARE" ]; then
  mkdir -p /srv/git && git init -q --bare -b main "$GIT_BARE"
  rm -rf "$WORK" && mkdir -p "$WORK"
  (cd "$SRC" && tar --exclude=.git --exclude='*.zip' -cf - .) | (cd "$WORK" && tar -xf -)
  cd "$WORK" && git init -q -b main
  git config user.name "Sriram R"; git config user.email "sram36505@gmail.com"
  git add -A && git commit -q -m "Initial release: MediCare Patient Portal" && git tag clean
  git remote add origin "$GIT_BARE" && git push -q origin main --tags
  cd "$SRC"
fi
git config --global --add safe.directory '*'
install -m 755 "$SRC/scripts/post-receive" "$GIT_BARE/hooks/post-receive"
install -m 755 "$SRC/scripts/jenkins-cli" /usr/local/bin/jenkins-cli
install -m 755 "$SRC/scripts/demo.sh" /usr/local/bin/demo

step "4/6  Building the pre-configured Jenkins image (3-5 min)"
docker build -q -t medicare-jenkins "$SRC/jenkins/image"

step "5/6  Starting Jenkins"
[ -s "$PASS_FILE" ] || openssl rand -hex 6 > "$PASS_FILE"
ADMIN_PASS="$(cat "$PASS_FILE")"
docker rm -f jenkins >/dev/null 2>&1 || true
mkdir -p /var/jenkins_home
docker run -d --name jenkins --restart unless-stopped --network host -u root \
  -v /var/jenkins_home:/var/jenkins_home \
  -v /var/run/docker.sock:/var/run/docker.sock \
  -v $CFG/kubeconfig:/var/lib/jenkins/.kube/config:ro \
  -v /srv/git:/srv/git \
  -e JENKINS_ADMIN_PASSWORD="$ADMIN_PASS" \
  -e APP_SECRET_KEY="$(openssl rand -hex 32)" \
  -e REPO_URL="file://$GIT_BARE" \
  -e NODE_IP="127.0.0.1" \
  -e JAVA_OPTS="-Xmx1g -Djenkins.install.runSetupWizard=false -Dhudson.plugins.git.GitSCM.ALLOW_LOCAL_CHECKOUT=true" \
  medicare-jenkins >/dev/null
echo "Waiting for Jenkins to start..."
until docker exec jenkins curl -fs -o /dev/null http://localhost:8080/login 2>/dev/null; do sleep 5; done
sleep 15

step "6/6  First run of all 3 pipelines (10-15 min)"
run() { echo "-> $*"; if jenkins-cli build "$@" -s >/dev/null 2>&1; then echo "   SUCCESS"; else echo "   FAILED - open Jenkins > job > Console Output"; fi; }
run pbl7-cicd
run pbl8-blue-green -p AUTO_APPROVE=true
run pbl8-blue-green -p AUTO_APPROVE=true
run pbl9-devsecops
demo status
