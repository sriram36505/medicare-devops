#!/usr/bin/env bash
# Run this in the AWS Academy Learner Lab terminal. It does all the AWS work for you:
#   firewall (security group) -> Ubuntu 24.04 server -> the server installs Jenkins, Docker,
#   Kubernetes and runs all 3 PBL pipelines by itself. At the end you get the links.
# Usage:  bash pbl3/scripts/launch.sh          (start / continue)
#         bash pbl3/scripts/launch.sh status   (show links + progress again)
set -uo pipefail
export AWS_DEFAULT_REGION="${AWS_DEFAULT_REGION:-us-east-1}"
export AWS_PAGER=""
NAME=devops-pbl3
SG_NAME=pbl3-auto-sg
REPO=https://github.com/sriram36505/medicare-devops.git
INFO="$HOME/pbl3-info.txt"

find_instance() {
  aws ec2 describe-instances --filters "Name=tag:Name,Values=$NAME" "Name=instance-state-name,Values=pending,running,stopping,stopped" \
    --query 'Reservations[].Instances[0].InstanceId' --output text 2>/dev/null | awk '{print $1}'
}
up() { [ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 "$1" 2>/dev/null)" = "200" ]; }

watch_progress() {
  local ID="$1" IP PASS
  aws ec2 start-instances --instance-ids "$ID" >/dev/null 2>&1 || true
  aws ec2 wait instance-running --instance-ids "$ID"
  IP=$(aws ec2 describe-instances --instance-ids "$ID" --query 'Reservations[0].Instances[0].PublicIpAddress' --output text)
  PASS=$(grep '^PASSWORD=' "$INFO" 2>/dev/null | cut -d= -f2)
  echo
  echo "Server $ID is running at $IP. It is now installing everything (about 25-35 minutes on first start)."
  echo "Progress is checked every 30 seconds. You can leave this open."
  local start=$SECONDS
  while true; do
    local j=. a=. b=. c=.
    up "http://$IP:8080/login"      && j=OK
    up "http://$IP:30007/health"    && a=OK
    up "http://$IP:30008/health"    && b=OK
    up "http://$IP:30009/health"    && c=OK
    printf "\r  %3d min | Jenkins:%-2s  PBL7:%-2s  PBL8:%-2s  PBL9:%-2s " $(( (SECONDS-start)/60 )) $j $a $b $c
    [ "$j$a$b$c" = "OKOKOKOK" ] && break
    [ $((SECONDS-start)) -gt 3600 ] && { echo; echo "Taking longer than 60 min - send a screenshot to Claude."; break; }
    sleep 30
  done
  cat <<MSG


 ===================== ALL DONE - MediCare DevOps PBL-III =====================
  Jenkins : http://$IP:8080        user: admin    password: ${PASS:-run 'sudo demo status' on the server}
  PBL 7   : http://$IP:30007       CI/CD + rolling update
  PBL 8   : http://$IP:30008       blue-green LIVE      preview: http://$IP:30018
  PBL 9   : http://$IP:30009       DevSecOps (hardened)

  Demo commands: EC2 console > Instances > $NAME > Connect > EC2 Instance Connect > Connect, then:
      sudo demo help
  Stop the server when you finish:  EC2 console > Instance state > Stop
 ==============================================================================
MSG
}

if [ "${1:-}" = "status" ] || [ -n "$(find_instance)" ]; then
  ID=$(find_instance)
  [ -z "$ID" ] && { echo "No PBL3 server found. Run: bash pbl3/scripts/launch.sh"; exit 1; }
  echo "Found existing PBL3 server: $ID"
  watch_progress "$ID"; exit 0
fi

echo "== 1/4  Finding the Ubuntu 24.04 image"
AMI=$(aws ec2 describe-images --owners 099720109477 \
  --filters "Name=name,Values=ubuntu/images/hvm-ssd-gp3/ubuntu-noble-24.04-amd64-server-*" "Name=state,Values=available" \
  --query 'sort_by(Images,&CreationDate)[-1].ImageId' --output text)
echo "   $AMI"

echo "== 2/4  Creating the firewall (ports 22, 8080, 30007, 30008, 30018, 30009)"
VPC=$(aws ec2 describe-vpcs --filters Name=isDefault,Values=true --query 'Vpcs[0].VpcId' --output text)
SG=$(aws ec2 describe-security-groups --filters "Name=group-name,Values=$SG_NAME" "Name=vpc-id,Values=$VPC" \
  --query 'SecurityGroups[0].GroupId' --output text 2>/dev/null)
if [ -z "$SG" ] || [ "$SG" = "None" ]; then
  SG=$(aws ec2 create-security-group --group-name "$SG_NAME" --description "PBL3 Jenkins and apps" --vpc-id "$VPC" --query GroupId --output text)
fi
for p in 22 8080 30007 30008 30018 30009; do
  aws ec2 authorize-security-group-ingress --group-id "$SG" --protocol tcp --port $p --cidr 0.0.0.0/0 >/dev/null 2>&1 || true
done
echo "   $SG"

PASS=$( (openssl rand -hex 6 2>/dev/null) || (date +%s%N | sha256sum | head -c 12) )
USERDATA="#!/bin/bash
echo '$PASS' > /root/jenkins-admin-password.txt
chmod 600 /root/jenkins-admin-password.txt
cd /root && git clone -q $REPO repo && cd repo && (unzip -oq pbl3.zip || python3 -m zipfile -e pbl3.zip .)
SUDO_USER=ubuntu bash pbl3/scripts/setup.sh > /var/log/pbl3-setup.log 2>&1"

echo "== 3/4  Launching the server (trying sizes your lab allows)"
ID=""
for TYPE in t3.large t2.large t3.medium t2.medium; do
  CREDIT=()
  [[ $TYPE == t3.* ]] && CREDIT=(--credit-specification CpuCredits=standard)
  CAND=$(aws ec2 run-instances --image-id "$AMI" --instance-type "$TYPE" --key-name vockey \
      --security-group-ids "$SG" "${CREDIT[@]}" \
      --block-device-mappings '[{"DeviceName":"/dev/sda1","Ebs":{"VolumeSize":30,"VolumeType":"gp3"}}]' \
      --user-data "$USERDATA" \
      --tag-specifications "ResourceType=instance,Tags=[{Key=Name,Value=$NAME}]" \
      --query 'Instances[0].InstanceId' --output text 2>/tmp/pbl3-err)
  if [ -z "$CAND" ] || [ "$CAND" = "None" ]; then echo "   $TYPE: not allowed ($(tail -c 150 /tmp/pbl3-err))"; continue; fi
  echo -n "   $TYPE: launched $CAND, checking the lab keeps it running"
  ok=1
  for i in 1 2 3 4 5 6; do
    sleep 10; echo -n "."
    ST=$(aws ec2 describe-instances --instance-ids "$CAND" --query 'Reservations[0].Instances[0].State.Name' --output text)
    case "$ST" in shutting-down|terminated|stopping|stopped) ok=0; break;; esac
  done
  if [ $ok = 1 ]; then echo " kept!"; ID=$CAND; break; fi
  echo " terminated by the lab, trying the next size"
done
[ -z "$ID" ] && { echo "The lab terminated every size. Open the Learner Lab 'Readme' > EC2 section and send Claude a screenshot."; exit 1; }

printf "INSTANCE=%s\nTYPE=%s\nPASSWORD=%s\n" "$ID" "$TYPE" "$PASS" > "$INFO"
echo "== 4/4  Server $ID ($TYPE) accepted. Saved details in $INFO"
watch_progress "$ID"
